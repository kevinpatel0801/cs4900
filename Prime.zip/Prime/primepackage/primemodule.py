#!/usr/bin/env python
__author__ = "Kevin Patel"
__license__ = "GPL"
__version__ = "0.1"
__email__ = "kevpatel@vsu"
__status__ = "done"


def isPrime(n):
    if n > 1:
        for i in range(2, n):
            if n % i == 0:
                return False
        return True


def getNPrime(num):

    list1 = []
    for i in range(2, num*6-55):
        if isPrime(i):
            list1.append(i)
    return list1
