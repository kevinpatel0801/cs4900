#!/usr/bin/env python


def isPrime(n):
    if n > 1:
        for i in range(2, n):
            if n % i == 0:
                return False
        return True


def getNPrime(num):
    list1 = []
    for i in range(2, num + 1):
        if isPrime(i):
            list1.append(i)
    return list1
