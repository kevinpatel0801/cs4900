#!/usr/bin/python


def write_primes(l, file_name):
    write_file = open(file_name, "w")
    write_file.write('%s\n' % l)


def read_primes(file_name):
    read_file = open(file_name, "r")
    if read_file.mode == "r":
        l = read_file.read()
        return l
