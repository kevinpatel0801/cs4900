#!/usr/bin/python


from .primeio import write_primes
from .primeio import read_primes
from .primemodule import getNPrime
